<?php
header('Content-Type: text/html; charset=UTF-8');

session_start();

$connection = null;
$del_holder = array('');
$del_holder_result = '';

// Step 1: Try connecting to server (without db)
function connectServerOnly() {
    if (!isset($_SESSION['db_login'])) return null;
    $conf = $_SESSION['db_login'];
try {
    $pdo = new PDO("mysql:host={$conf['host']}", $conf['user'], $conf['pass']);
    $pdo->exec("SET NAMES 'utf8mb4'");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    return $pdo;
} catch (PDOException $e) {
    $_SESSION['db_error'] = "❌ Connection failed: " . $e->getMessage();
    return null;
}

}

// Step 2: Try connecting to selected database
function connectToSelectedDB() {
    if (!isset($_SESSION['db_login']) || !isset($_SESSION['db_selected'])) return null;
    $conf = $_SESSION['db_login'];
    $dbname = $_SESSION['db_selected'];
    try {
        $pdo = new PDO("mysql:host={$conf['host']};dbname={$dbname}", $conf['user'], $conf['pass']);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    } catch (PDOException $e) {
        return null;
    }
}

// Step 3: Handle connect to server
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['db_action']) && $_POST['db_action'] === 'connect_server') {
    $_SESSION['db_login'] = [
        'host' => $_POST['dbhost'] ?: 'localhost',
        'user' => $_POST['dbuser'],
        'pass' => $_POST['dbpass']
    ];
    header("Location: ".$_SERVER['PHP_SELF']);
    exit;
}

// Step 4: Handle select database
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['db_action']) && $_POST['db_action'] === 'select_db') {
    $_SESSION['db_selected'] = $_POST['dbname'];
    header("Location: ".$_SERVER['PHP_SELF']);
    exit;
}

// Step 5: Handle disconnect
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['db_action']) && $_POST['db_action'] === 'disconnect') {
    session_unset();
    session_destroy();
    header("Location: ".$_SERVER['PHP_SELF']);
    exit;
}

$serverOnly = connectServerOnly();
$connection = connectToSelectedDB();

// Trace logic
function get_npcid($npc_id){
    global $connection, $del_holder, $del_holder_result;
    $return_result = '';

    if (!$connection) {
        return "❌ Not connected to a database.";
    }

    if ($npc_id == "") {
        return "⚠️ No ID provided.";
    }

    try {
        $stmt = $connection->prepare("SELECT * FROM cq_action WHERE id=:npc_id");
        $stmt->bindParam(':npc_id', $npc_id, PDO::PARAM_INT);
        $stmt->execute();
        $data = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        if (str_contains($e->getMessage(), 'base table or view not found') || str_contains($e->getMessage(), '1146')) {
            return "❌ Table cq_action not found in the selected database.";
        }
        return "❌ Database error: " . htmlspecialchars($e->getMessage());
    }

    if (!$data) {
        return "❌ No action found with ID $npc_id.";
    }

    // Proceed as usual
    getAction($data['id'], 1, '', '');
    $return_result .= $del_holder_result;

    $del_holder = array('');
    $del_holder_result = '';
    $return_result .= getAction($data['id'], 1, '', '');

    return $return_result;
}



function getAction($idAction, $actionCount, $typeAction, $idParrent){
    global $del_holder, $del_holder_result, $connection;
    $queryAction = '';

    if ($idAction != 0 && $idAction != "") {
        $stmt = $connection->prepare("SELECT * FROM cq_action WHERE id=:idAction");
        $stmt->bindParam(':idAction', $idAction, PDO::PARAM_INT);
        $stmt->execute();
        if ($stmt->rowCount() != 0) {
            $dataAction = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!in_array($dataAction['id'], $del_holder)) {
                array_push($del_holder, $dataAction['id']);

                $queryAction .= 'REPLACE INTO `cq_action` VALUES (' .
                    $dataAction['id'] . ', ' .
                    $dataAction['id_next'] . ', ' .
                    $dataAction['id_nextfail'] . ', ' .
                    $dataAction['type'] . ', ' .
                    $dataAction['data'] . ', "' .
                    $dataAction['param'] . '");' . "\n";

                $actionCount++;

                $queryAction .= getAction($dataAction['id_next'], $actionCount, "success", $dataAction['id']);
                $queryAction .= getAction($dataAction['id_nextfail'], $actionCount, "fail", $dataAction['id']);






$traceTypes = ["0102", "2012", "0122", "0188", "1412", "0134", "2020", "8000", "8001", "8002", "8003", "8005", "8006"];

if (in_array($dataAction['type'], $traceTypes)) {
    if ($dataAction['type'] === "0122") {
        $ids = preg_split('/\s+/', trim($dataAction['param']));
        foreach ($ids as $clickAction) {
            if (is_numeric($clickAction) && !in_array($clickAction, $del_holder)) {
                $queryAction .= getAction($clickAction, 1, "Click_Action", $clickAction);
            }
        }
		
	} elseif (in_array($dataAction['type'], ["1412", "8000", "8001", "8002", "8003", "8005", "8006"])) {
    $clickAction = trim($dataAction['param']);
    if (is_numeric($clickAction) && !in_array($clickAction, $del_holder)) {
        $queryAction .= getAction($clickAction, 1, "Click_Action", $clickAction);
    }
		
	} elseif ($dataAction['type'] === "2020") {
    $parts = preg_split('/\s+/', trim($dataAction['param']));
    $clickAction = $parts[5] ?? null;
    if (is_numeric($clickAction) && !in_array($clickAction, $del_holder)) {
        $queryAction .= getAction($clickAction, 1, "Click_Action", $clickAction);
    }
	
    } elseif ($dataAction['type'] === "2012") {
        $parts = preg_split('/\s+/', trim($dataAction['param']));
        $clickAction = $parts[1] ?? null;
        if (is_numeric($clickAction) && !in_array($clickAction, $del_holder)) {
            $queryAction .= getAction($clickAction, 1, "Click_Action", $clickAction);
        }
    } elseif ($dataAction['type'] === "0188") {
        $entries = explode(',', trim($dataAction['param']));
        foreach ($entries as $entry) {
            $parts = preg_split('/\s+/', trim($entry));
            $clickAction = $parts[2] ?? null;
            if (is_numeric($clickAction) && !in_array($clickAction, $del_holder)) {
                $queryAction .= getAction($clickAction, 1, "Click_Action", $clickAction);
            }
        }
    } elseif ($dataAction['type'] === "0134") {
        $parts = preg_split('/\s+/', trim($dataAction['param']));
        $clickAction = $parts[0] ?? null;
        if (is_numeric($clickAction) && !in_array($clickAction, $del_holder)) {
            $queryAction .= getAction($clickAction, 1, "Click_Action", $clickAction);
        }
    } else {
        // Default: last number
        preg_match('/(\d{6,})$/', $dataAction['param'], $match);
        $clickAction = $match[1] ?? null;
        if ($clickAction && !in_array($clickAction, $del_holder)) {
            $queryAction .= getAction($clickAction, 1, "Click_Action", $clickAction);
        }
    }
}












                return $queryAction;
            }
        }
    }
    return '';
}

// AJAX handler
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax']) && $_POST['ajax'] === '1') {
    $npc_id = htmlspecialchars(trim($_POST['npc_id']));
    echo get_npcid($npc_id);
    exit;
}

// Handle AJAX database selection
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax']) && $_POST['ajax'] === 'set_db') {
    $_SESSION['db_selected'] = $_POST['dbname'];
    echo "OK";
    exit;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>🔍 Trace CQ Action | DuaSelipar Tools</title>
  <meta name="theme-color" content="#ff6f61">  
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/alertify.min.css"/>
  <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/themes/bootstrap.min.css"/>
  <style>
    body {
      background: linear-gradient(-45deg, #ee7752, #e73c7e, #23a6d5, #23d5ab);
      background-size: 400% 400%;
      animation: gradient 15s ease infinite;
      min-height: 100vh;
    }
    @keyframes gradient {
      0% {background-position: 0% 50%;}
      50% {background-position: 100% 50%;}
      100% {background-position: 0% 50%;}
    }
  </style>
</head>
<body class="d-flex flex-column min-vh-100">

<?php if (isset($_SESSION['db_error'])): ?>
<script>
window.addEventListener("DOMContentLoaded", () => {
  alertify.error("<?= addslashes($_SESSION['db_error']) ?>");
});
</script>
<?php unset($_SESSION['db_error']); endif; ?>

<div class="container py-5 text-white flex-grow-1">
<h2 class="mb-4 text-center text-white fw-bold" style="text-shadow: 1px 1px 5px rgba(0,0,0,0.7);">
  🧠 Trace <span class="text-warning">CQ Action</span> Tool
</h2>

  <div class="card mb-4">
    <div class="card-body">
      <h5 class="card-title">Database Connection</h5>

      <?php if (!$serverOnly): ?>
        <form method="post" class="row g-2">
          <input type="hidden" name="db_action" value="connect_server">
          <div class="col-md-3"><input type="text" name="dbhost" class="form-control" placeholder="Host (localhost)"></div>
          <div class="col-md-3"><input type="text" name="dbuser" class="form-control" placeholder="Username" required></div>
          <div class="col-md-3"><input type="password" name="dbpass" class="form-control" placeholder="Password"></div>
          <div class="col-md-3"><button class="btn btn-success w-100">Connect</button></div>
        </form>
<?php elseif ($serverOnly): ?>
        <p class="text-success">✅ Connected to server as <strong><?= $_SESSION['db_login']['user'] ?></strong></p>
<div class="row g-2 mt-3">
  <div class="col-md-6">
    <select id="selectDB" class="form-select" required>
      <option value="">-- Select Database --</option>
      <?php
      $dbs = $serverOnly->query("SHOW DATABASES");
      while ($row = $dbs->fetch(PDO::FETCH_ASSOC)) {
        $selected = isset($_SESSION['db_selected']) && $_SESSION['db_selected'] === $row['Database'] ? 'selected' : '';
        echo '<option value="'.$row['Database'].'" '.$selected.'>'.$row['Database'].'</option>';
      }
      ?>
    </select>
  </div>
  <div class="col-md-3">
    <form method="post" onsubmit="clearStorage()">
      <input type="hidden" name="db_action" value="disconnect">
      <button class="btn btn-danger w-100">Disconnect</button>
    </form>
  </div>
</div>

      <?php else: ?>
        <p class="text-success">✅ Connected to <strong><?= $_SESSION['db_selected'] ?></strong> as <strong><?= $_SESSION['db_login']['user'] ?></strong></p>
        <form method="post">
          <input type="hidden" name="db_action" value="disconnect">
          <button class="btn btn-danger">Disconnect</button>
        </form>
      <?php endif; ?>
    </div>
  </div>

  <?php if ($connection): ?>
  <form onsubmit="traceAction(); return false;">
    <div class="mb-3">
      <label for="npc_id" class="form-label">NPC Action ID</label>
      <input type="text" name="npc_id" id="npc_id" class="form-control" placeholder="Enter Action ID">
    </div>

    <div class="d-flex flex-wrap gap-2 mb-3">
      <button type="submit" class="btn btn-warning">Trace Action &#10140;</button>
      <button type="button" class="btn btn-secondary" onclick="myFunction1()">Select All</button>
      <button type="button" class="btn btn-primary" onclick="myFunction()">Copy All</button>
      <button type="button" class="btn btn-danger" onclick="document.getElementById('myInput').value = ''; myFunction2();">Clear</button>
    </div>

<textarea class="form-control" id="myInput" rows="20" placeholder="Result will appear here..." style="white-space: pre; font-family: monospace;" spellcheck="false"></textarea>
  </form>
  <?php endif; ?>
</div>

<footer class="text-center text-white py-3 mt-auto" style="background-color: rgba(0, 0, 0, 0.5);">
  <p>&copy; <?= date('Y') ?> Dev Hub. Powered by GitHub Pages | Design by 
    <strong>
      <a href="https://www.facebook.com/profile.php?id=61554036273018" target="_blank" class="text-warning text-decoration-none">
        DuaSelipar
      </a>
    </strong>
  </p>
</footer>



<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>
<script>
function myFunction() {
  var copyText = document.getElementById("myInput");
  copyText.select();
  document.execCommand("copy");
  alertify.success("All text copied");
}
function myFunction1() {
  document.getElementById("myInput").select();
  alertify.message("All text selected");
}
function myFunction2() {
  alertify.error("Text cleared");
}
function traceAction() {
  const id = document.getElementById('npc_id').value;
  if (id.trim() === '') {
    alertify.error("ID cannot be empty");
    return;
  }

  alertify.message("Tracing...");

  fetch("traceaction.php", {
    method: "POST",
    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
    body: new URLSearchParams({
      ajax: '1',
      npc_id: id
    })
  })
  .then(res => res.text())
  .then(data => {
    document.getElementById("myInput").value = data;
    alertify.success("Trace Complete");
  })
  .catch(err => {
    alertify.error("Error fetching data");
    console.error(err);
  });
}
</script>
<script>
// Auto-prefill from localStorage
window.addEventListener("DOMContentLoaded", () => {
  const host = localStorage.getItem("dbhost");
  const user = localStorage.getItem("dbuser");
  const pass = localStorage.getItem("dbpass");
  if (host) document.querySelector("input[name='dbhost']")?.value = host;
  if (user) document.querySelector("input[name='dbuser']")?.value = user;
  if (pass) document.querySelector("input[name='dbpass']")?.value = pass;
});

// Simpan ke localStorage bila connect
document.addEventListener("submit", function(e) {
  const form = e.target;
  const action = form.querySelector("input[name='db_action']");
  if (action && action.value === "connect_server") {
    localStorage.setItem("dbhost", form.querySelector("input[name='dbhost']").value);
    localStorage.setItem("dbuser", form.querySelector("input[name='dbuser']").value);
    localStorage.setItem("dbpass", form.querySelector("input[name='dbpass']").value);
  }
});

// Clear localStorage bila disconnect
function clearStorage() {
  localStorage.removeItem("dbhost");
  localStorage.removeItem("dbuser");
  localStorage.removeItem("dbpass");
}
</script>
<script>
document.getElementById('selectDB')?.addEventListener('change', function () {
  const dbname = this.value;
  if (!dbname) return;
  fetch("traceaction.php", {
    method: "POST",
    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
    body: new URLSearchParams({
      ajax: "set_db",
      dbname: dbname
    })
  })
  .then(res => res.text())
  .then(result => {
    if (result === "OK") {
      alertify.success("Database selected: " + dbname);
      location.reload(); // reload so that connection is refreshed
    } else {
      alertify.error("Failed to select database");
    }
  });
});
</script>

</body>
</html>
